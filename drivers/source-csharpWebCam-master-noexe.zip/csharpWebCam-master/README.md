# C# WebCam
This repository holds source code for [Versatile WebCam C# library](http://www.codeproject.com/Articles/125478/Versatile-WebCam-C-library) article:
http://www.codeproject.com/Articles/125478/Versatile-WebCam-C-library

All future code revisions should be done using [GitHub repository](https://github.com/lepipele/csharpWebCam) so everyone can participate and benefit:
https://github.com/lepipele/csharpWebCam

I've retained compatibility with Visual Studio 2010 and please do the same in your pull requests. 
If you don't have VS2010 installed on your machine, to build C++ project you may need to [install Visual C++ 2010 Express](http://www.visualstudio.com/downloads/download-visual-studio-vs#DownloadFamilies_4) from this link:

http://www.visualstudio.com/downloads/download-visual-studio-vs#DownloadFamilies_4
