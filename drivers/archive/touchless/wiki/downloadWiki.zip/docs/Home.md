# Have you seen the news from E3 2009?
See the videos from Microsoft's [Project Natal](http://news.bbc.co.uk/2/hi/technology/8077369.stm) and Sony's [motion controller](http://news.bbc.co.uk/1/hi/technology/8080511.stm)
Touchless is conceptually similar to those projects, but was not used in their development.
With Touchless you can create similar natural interaction experiences using only a webcam!
# What is Touchless?
Touchless is a fun, webcam multi-"touch" object tracking SDK project.
Watch the **[Touchless video](http://www.youtube.com/watch?v=hJuJJOK7MMc)** and try the **[newest demos](http://touchless.codeplex.com/SourceControl/ListDownloadableCommits.aspx)** including the new mouse control demo!
Check out Lucian Wischik's exciting game **[Stay In The Game](http://code.msdn.microsoft.com/vbtouchless)** and VB sample project!
* Simulate multi-"touch" input with M&Ms, tennis balls, or markers
* Fun games, demos, community projects, and an extensible demo application
* SDK with good documentation, add multi-"touch" to your own applications
* Free and open-source project, games, and demos
# What's Next?
Learn more and join the community of users and contributors.
* [Intro Video](http://www.youtube.com/watch?v=hJuJJOK7MMc) - Watch a quick pitch and demo
* [Project Files](http://touchless.codeplex.com/SourceControl/ListDownloadableCommits.aspx) - Download the SDK and demos
* [FAQ](FAQ) - Frequently asked questions
* [Media](Media) - Media and press items
* [Community](Community) -  Community and projects
# Touchless needs you!
We have some great ideas to improve Touchless for users and developers alike. Together, we can create compelling, natural, and fun user experiences. Unfortunately, I have no regular contributors to the project, and a lot of my ideas and your feedback are falling to the wayside. Consider this your personal invitation to join the Touchless project as a contributor!

Unleash the power of your webcam!