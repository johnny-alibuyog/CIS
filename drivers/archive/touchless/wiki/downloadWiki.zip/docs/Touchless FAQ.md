**What is the Touchless SDK?** 
The Touchless SDK is an open source SDK for .NET applications. It enables developers to create multi-touch based applications using a webcam for input. Color based markers defined by the user are tracked and their information is published through events to clients of the SDK.  In a nutshell, the Touchless SDK enables touch without touching. 

**What is the Touchless Demo?**
The Touchless Demo is an open source application that anyone with a webcam can use to experience multi-touch, no geekiness required. The demo was created using the Touchless SDK and Windows Forms with C#.

**What does open source mean?**
Open source means the [source code for the Touchless SDK and Demo](http://www.codeplex.com/touchless/SourceControl/ListDownloadableCommits.aspx) is available for anyone to see, to use and to contribute to. For more information on open source check out the [Open Source Initiative](http://www.opensource.org/). 

**Are there any restrictions to using the Touchless SDK and Demo code?**
Yes. [Touchless License](http://www.codeplex.com/touchless/license) uses the Microsoft Public License (MS-PL).

**Why is Touchless open source?**
There is so much potential with Touchless, however Office Labs has limited resources so we would want to encourage anyone to contribute and benefit from this project. 

**What are the requirements for Touchless?**
Windows Vista or Windows XP
Webcam 
Color Markers (M&Ms, ends of pens, painted finger nails, etc.)

**What types of webcams are supported?**
DirectX 9 DirectShow compliant webcams. If you don’t know what that means don’t worry about it neither did I - most webcams should work.
We used [Microsoft LifeCams](http://www.microsoft.com/hardware/digitalcommunication/Productlist.aspx?typeLifeCam) VX-3000 and VX-6000.

**How can I try out the Touchless demo?**
Save [release:17986](release_17986) to your computer
Right click on the compressed folder select Extract All…
Make sure you have a webcam hooked up
Double click TouchlessDemo.exe

**How can I build my own Touchless applications?**
Save [release:17986](release_17986) to your computer
Right click on the compressed folder select Extract All…
Follow the instructions provided in Touchless.rtf
You can also watch our video walkthrough of creating a drawing application

**Who developed the Touchless SDK and Demo?**
Touchless was created by Mike Wasserman initially as a college project to provide a cheap way to experience multi-touch capabilities, without expensive hardware or software. Mike joined Microsoft as a developer on the Office Graphics team and continues to work on this project on his own time.  Mike received support from [Office Labs](http://www.officelabs.com), which offers assistance to “weekend coders” at Microsoft.

**What type of assistance did the Touchless project receive from Office Labs?**
[Office Labs](http://www.officelabs.com) provided Mike with resources to help design, implement and release the SDK and demo. 

**Will Touchless be integrated into a Microsoft product?**
There are no plans for Touchless to be integrated into a Microsoft product.

**How can I get support for Touchless?**
You are request support in the [Discussions](http://www.codeplex.com/touchless/Thread/List.aspx) section.

**How can I share feedback and ideas on Touchless?**
You can share your feedback and ideas in the [Discussions](http://www.codeplex.com/touchless/Thread/List.aspx) section.
You can also vote on feature requests or post your own in the [Issue Tracker](http://www.codeplex.com/touchless/WorkItem/List.aspx) section.

**How can I post my demo here or contribute to Touchless?**
Request access by getting in touch with [Mike Wasserman](https://www.codeplex.com/site/users/contact/michwass)

**I have a question that isn’t answered here. What should I do?**
You can ask your questions in the [Discussions](http://www.codeplex.com/touchless/Thread/List.aspx) section.
You can also get in touch with [Mike Wasserman](https://www.codeplex.com/site/users/contact/michwass)