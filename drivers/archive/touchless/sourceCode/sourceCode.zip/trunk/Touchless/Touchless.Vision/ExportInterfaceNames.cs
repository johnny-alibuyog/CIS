﻿namespace Touchless.Vision
{
    internal class ExportInterfaceNames
    {
        internal const string DefaultCamera = "Touchless.Camera.CameraService.DefaultCamera";
    }
}
